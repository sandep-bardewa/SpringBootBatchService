package batchExecutorService.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import batchExecutorService.entity.DeviceResponse;

@Component
public class BatchExecutorServiceClient {

	@Autowired
	RestTemplate restTemplate;

	@SuppressWarnings("unchecked")
	public ResponseEntity<DeviceResponse> getDeviceList(String chunkId) {

		ResponseEntity<DeviceResponse> response = restTemplate.exchange(
				"http://batchDevice/bds/fetchDeviceList/{chunkId}", HttpMethod.GET, null, DeviceResponse.class,
				chunkId);

		return response;

	}

}
