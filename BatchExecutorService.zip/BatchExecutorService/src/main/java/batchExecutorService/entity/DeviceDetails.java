package batchExecutorService.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "DEVICE_DETAILS")
public class DeviceDetails implements Serializable{
	@Id
	@GeneratedValue
	@Column(name = "DEVICE_ID")
	private String deviceId;

	private Boolean statusOfUpgrade;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "CHUNK_ID", referencedColumnName = "CHUNK_ID", insertable = false, updatable = false)
	@JsonIgnore
	private BatchDetails batchDetails;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public Boolean getStatusOfUpgrade() {
		return statusOfUpgrade;
	}

	public void setStatusOfUpgrade(Boolean statusOfUpgrade) {
		this.statusOfUpgrade = statusOfUpgrade;
	}

	@JsonIgnore
	public BatchDetails getBatchDetails() {
		return batchDetails;
	}
	
	@JsonProperty
	public void setBatchDetails(BatchDetails batchDetails) {
		this.batchDetails = batchDetails;
	}

//	@Override
//	public String toString() {
//		return "DeviceDetails [deviceId=" + deviceId + ", statusOfUpgrade=" + statusOfUpgrade + ", batchDetails="
//				+ batchDetails + "]";
//	}

}
