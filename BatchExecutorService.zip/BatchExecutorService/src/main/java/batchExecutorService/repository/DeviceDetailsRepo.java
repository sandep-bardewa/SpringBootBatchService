package batchExecutorService.repository;

import org.springframework.data.repository.CrudRepository;

import batchExecutorService.entity.DeviceDetails;

public interface DeviceDetailsRepo extends CrudRepository<DeviceDetails, String> {

}
