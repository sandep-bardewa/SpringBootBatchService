package batchExecutorService.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import batchExecutorService.client.BatchExecutorServiceClient;
import batchExecutorService.entity.DeviceDetails;
import batchExecutorService.entity.DeviceResponse;
import batchExecutorService.repository.BatchDetailsRepo;
import batchExecutorService.repository.DeviceDetailsRepo;

@Service
public class BatchExecutorServiceImp implements BatchExecutorService {
	@Autowired
	DeviceDetailsRepo deviceDetailsRepo;
	@Autowired
	BatchDetailsRepo batchDetailsRepo;
	@Autowired
	BatchExecutorServiceClient batchExecutorServiceClient;

	@Override
	public void upgrade(String chunkId) throws InterruptedException, ExecutionException {

		ResponseEntity<DeviceResponse> deviceList = batchExecutorServiceClient.getDeviceList(chunkId);
		DeviceResponse deviceResponse = deviceList.getBody();
		List<DeviceDetails> details = deviceResponse.getDeviceLst();
		List<Future<DeviceDetails>> futures = new ArrayList<Future<DeviceDetails>>();
		ExecutorService executorService = Executors.newFixedThreadPool(30);
		for (DeviceDetails device : details) {
			Future<DeviceDetails> changedDeviceDetails=executorService.submit(new UpgradeDevice(device));
			

		}
		executorService.shutdown();

	}

}
