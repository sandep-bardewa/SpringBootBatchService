package batchExecutorService.service;

import java.util.concurrent.Callable;

import batchExecutorService.entity.DeviceDetails;

public class UpgradeDevice implements Callable<DeviceDetails> {
	private DeviceDetails deviceDetails;

	@Override
	public DeviceDetails call() throws Exception {
		
		System.out.println("Device with device Id: "+deviceDetails.getDeviceId()+" upgraded!" );
		deviceDetails.setStatusOfUpgrade(true);
		return deviceDetails;
	}

	public UpgradeDevice(DeviceDetails deviceDetails) {
		super();
		this.deviceDetails = deviceDetails;
	}

}
