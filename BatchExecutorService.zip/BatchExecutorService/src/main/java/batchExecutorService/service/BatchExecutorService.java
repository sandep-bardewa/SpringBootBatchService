package batchExecutorService.service;

import java.util.concurrent.ExecutionException;

public interface BatchExecutorService {
	void upgrade(String chunkId) throws InterruptedException, ExecutionException;

}
