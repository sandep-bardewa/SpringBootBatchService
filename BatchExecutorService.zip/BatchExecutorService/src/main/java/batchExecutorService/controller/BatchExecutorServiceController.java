package batchExecutorService.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import batchExecutorService.service.BatchExecutorService;

@RequestMapping("/bes")
@RestController
public class BatchExecutorServiceController {
	
	@Autowired
	BatchExecutorService batchExecutorService;
	
	@PutMapping("/upgrade/{chunkId}")
	public void upgrade(@PathVariable(value = "chunkId") String chunkId) throws InterruptedException, ExecutionException {
		batchExecutorService.upgrade(chunkId);
		
	}

}
