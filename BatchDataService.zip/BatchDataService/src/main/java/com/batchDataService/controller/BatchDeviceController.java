package com.batchDataService.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.batchDataService.entity.BatchDetails;
import com.batchDataService.entity.DeviceDetails;
import com.batchDataService.entity.DeviceResponse;
import com.batchDataService.repository.service.BatchDataService;

@RestController
@RequestMapping("/bds")
public class BatchDeviceController {

	@Autowired
	private BatchDataService batchDataService;

	@GetMapping("/fetchBatchChunk")
	public List<BatchDetails> fetchBatchChunk() {
		List<BatchDetails> results = batchDataService.fetchBatchChunk();
		return results;
	}

	@GetMapping("/fetchDeviceList/{chunkId}")
	public ResponseEntity<DeviceResponse> fetchDeviceListByChunkId(@PathVariable("chunkId") String chunkId) {
		List<DeviceDetails> deviceList = batchDataService.fetchDeviceListByChunkId(chunkId);
		return new ResponseEntity<>(new DeviceResponse(deviceList), HttpStatus.OK);

	}

	@PutMapping("updateDevice/{chunkId}")
	public ResponseEntity<String> updateByChunkId(@PathVariable("chunkId") String chunkId) {
		batchDataService.updateByChunkId(chunkId);
		return new ResponseEntity<>("Device status updated", HttpStatus.OK);

	}
	
	@PutMapping("updateDeviceDeviceId/{deviceId}")
	public ResponseEntity<String> updateByDeviceId(@PathVariable("deviceId") String deviceId) {
		batchDataService.updateByDeviceId(deviceId);
		return new ResponseEntity<>("Device status updated", HttpStatus.OK);

	}

}
