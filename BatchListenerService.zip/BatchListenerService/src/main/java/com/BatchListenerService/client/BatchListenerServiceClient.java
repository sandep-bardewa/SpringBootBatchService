package com.BatchListenerService.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class BatchListenerServiceClient {

	@Autowired
	RestTemplate restTemplate;

	@SuppressWarnings("unchecked")
	public ResponseEntity<String> updateStatus(String deviceId) {

		ResponseEntity<String> response = restTemplate.exchange("http://batchDevice/bds/updateDevice/{deviceId}",HttpMethod.PUT, null, String.class, deviceId);

		return response;

	}

}
