package com.BatchListenerService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.BatchListenerService.client.BatchListenerServiceClient;

@Service
public class BatchListenerServiceImp implements BatchListenerService{
	
	@Autowired
	BatchListenerServiceClient batchListenerServiceClient;

	@Override
	public void updateStatusForDevice(String deviceID, Boolean status) {
		// TODO Auto-generated method stub
		batchListenerServiceClient.updateStatus(deviceID);
		
		
	}

}
