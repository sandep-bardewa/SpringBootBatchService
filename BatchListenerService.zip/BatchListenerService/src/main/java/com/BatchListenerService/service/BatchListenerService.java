package com.BatchListenerService.service;

public interface BatchListenerService {
	
	void updateStatusForDevice(String deviceID,Boolean status);

}
