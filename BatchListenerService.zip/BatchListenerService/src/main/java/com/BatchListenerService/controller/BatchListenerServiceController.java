package com.BatchListenerService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BatchListenerService.service.BatchListenerService;

@RestController
@RequestMapping("/bls")
public class BatchListenerServiceController {
	
	@Autowired BatchListenerService batchListenerService;
	@PutMapping("/statusFromDevice/{deviceId}/{status}")
	public void updateStatusForDevice(@PathVariable(value = "deviceId") String deviceId,
			@PathVariable(value = "status") Boolean status) {
		batchListenerService.updateStatusForDevice(deviceId, status);
		
	}

}
