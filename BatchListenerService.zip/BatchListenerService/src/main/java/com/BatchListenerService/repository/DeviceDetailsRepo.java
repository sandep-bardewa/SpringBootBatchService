package com.BatchListenerService.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.BatchListenerService.entity.DeviceDetails;

@Repository
public interface DeviceDetailsRepo extends CrudRepository<DeviceDetails, String> {

}
